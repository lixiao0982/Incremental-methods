clear; 
close all;
rand('seed',2018);randn('seed',2018);

%parameter setting
n = 100; 
m = 10*n;
p_fail = 0.3;
maxiter = 500;


%-----generate data-----  
[ b, A, xo ] = generate_RPRdata( m,n,p_fail );

%random initialization
x_0 = randn(n,1); 



%-------SubGM-------
%random initialization
mu_0 = 1/m; rho = 0.90;
x = x_0;
% dist_ed1(1) = min(norm(x-xo,'fro'),norm(x+xo,'fro'));
for Iter = 1:maxiter
    mu = mu_0 * rho^Iter;
    dist_ed1(Iter) = min(norm(x-xo,'fro'),norm(x+xo,'fro'));
    grad = A'* (  (A*x).* sign((A*x).^2 -b) );
    x = x - mu*grad;
end









%-------incremental subgradient method-------
%random initialization
mu_0 = 30/m; rho = 0.7;
x = x_0;
for Iter = 1:maxiter
    x_inner = x;
    mu = mu_0 * rho^Iter;
    dist_ed2(Iter) = min(norm(x-xo,'fro'),norm(x+xo,'fro'));
    for iter = 1:m %inner update
        %incremental subgradient
        aix = A(iter,:)*x_inner;
        grad = aix * sign( aix^2 - b(iter) ) * A(iter,:)';
        %update
        x_inner = x_inner - mu*grad;
    end
    %outer update
    x = x_inner;
    
end





%-------stochastic subgradient method-------
%random initialization
mu_0 = 1/m; rho = 0.85;
x = x_0;
for Iter = 1:maxiter
    x_inner = x;
    mu = mu_0 * rho^Iter;
    dist_ed3(Iter) = min(norm(x-xo,'fro'),norm(x+xo,'fro'));
    for iter = 1:m %inner update
        %incremental subgradient
        idx = randperm(m,1);
        aix = A(idx,:)*x_inner;
        grad = aix * sign( aix^2 - b(idx) ) * A(idx,:)';
        %update
        x_inner = x_inner - mu*grad;
    end
    %outer update
    x = x_inner;
end







figure;
semilogy(dist_ed1,'k-','LineWidth',2); hold on;
semilogy(dist_ed2,'r--','LineWidth',2); 
semilogy(dist_ed3,'b-.','LineWidth',2); 
% xlim([0 500])
ylim([1e-15 100])
% set(gcf,'Position',[100 300 650 300],'color','w');
set(gca, 'LineWidth' , 1.8,'FontSize',20);
set(gcf, 'Color', 'w');
xlabel('Iteration','FontSize',20);
ylabel('dist$({\bf x}_k, {\cal D})$','FontSize',25,'FontName', 'Times New Roman','Interpreter','LaTex');
legen = legend('GD, $\rho = 0.9, \mu_0 = 1/m$','IGD, $\rho = 0.7, \mu_0 = 30/m$','SGD, $\rho = 0.85, \mu_0 = 1/m$');
set(legen,'Interpreter','LaTex');



