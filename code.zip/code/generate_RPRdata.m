function [ b, A, xo ] = generate_RPRdata( m,n,p_fail );


rand('seed',2018);randn('seed',2018);




%-----generate data-----   
%ground truth
xo = randn(n,1);


%sensing
A = randn(m,n);
bo = (A*xo).^2;

%add outliers
s = zeros(m,1);
indx = randperm(m);
s(indx(1:floor(p_fail*m))) = 10*randn(floor(p_fail*m),1);
%observation
b = bo + s;


end
