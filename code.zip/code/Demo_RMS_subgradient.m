%subgradient method and incremental subgradient and stochastic subgradient
%method for solving RMS

clear; 
close all;
rand('seed',2018);randn('seed',2018);

%parameter setting
n=50;  
r = 5;
m = 5*n*r;
p_fail = 0.3;
maxiter = 500;


Uo=randn(n,r);
X=Uo*Uo';


%sensing
yo=zeros(m,1); Acell=cell(m,1);
for it=1:m
    Acell{it}=randn(n,n);
    yo(it)=trace(X'*Acell{it});
end


%add outliers
s = zeros(m,1);
indx = randperm(m);
s(indx(1:floor(p_fail*m))) = 10*randn(floor(p_fail*m),1);
%observation
y = yo + s;


Aop=zeros(m,n^2);
for it=1:m
    AA = Acell{it};
    Aop(it,:)=AA(:)';
end


%random initlization 
U_0 = randn(n,r);




%-----------full subgradient------------
mu_0 = 1/m; rho = 0.93;
%random initialization
U = U_0;
% dist_ed1(1) = norm(U*U' - X,'fro');
for i = 1:maxiter
    %stepsize
    mu = mu_0*rho^i;
    dist_ed1(i) = norm(U*U' - X,'fro');
    %gradient
    dev=Aop*vec(U*U')-y;
    gradU = (A_adj(sign(dev),Acell,m)*U) + (A_adj(sign(dev),Acell,m)'*U);
    %update
    U = U - mu*gradU;
end









%--------incremental subgradient method--------
mu_0 = 30/m; rho = 0.75;
%random initialization
U = U_0;
for Iter = 1:maxiter %outter iteration
    W = U;
    mu = mu_0*rho^Iter; %stepsize
    %calculation
    dist_ed2(Iter) = norm(U*U' - X,'fro');
    for iter = 1:m  %inner update
        %incremental gradient
        dev =trace(W'*Acell{iter}*W)-y(iter);
        gradW = ( sign(dev)*Acell{iter} + (sign(dev)*Acell{iter})' ) *W;
        %update
        W = W - mu*gradW;    
    end
    %outer update
    U = W;
end









%--------SGD--------
batchsize = 1;
mu_0 = 30/m; rho = 0.9;
%random initialization
U = U_0;
for Iter = 1:maxiter %outter iteration
    W = U;
    mu = (mu_0*rho^Iter)/batchsize; %stepsize
    %calculation
    dist_ed3(Iter) = norm(U*U' - X,'fro');
    for i = 1:m
        index =  randperm(m,batchsize); %random index
        %construct minibatch gradient
        dev =trace(W'*Acell{index}*W)-y(index);
        gradW = ( sign(dev)*Acell{index} + (sign(dev)*Acell{index})' ) *W;
        W = W - mu*gradW;
    end
    U = W;
end 


figure
semilogy(dist_ed1,'k','LineWidth',2); hold on;
semilogy(dist_ed2,'r--','LineWidth',2); 
semilogy(dist_ed3,'b-.','LineWidth',2); 
% xlim([0 500])
ylim([1e-15 1000])
% set(gcf,'Position',[100 300 650 300],'color','w');
set(gca, 'LineWidth' , 1.8,'FontSize',20);
set(gcf, 'Color', 'w');
xlabel('Iteration','FontSize',20);
ylabel('dist$({\bf U}_k, {\cal U})$','FontSize',25,'FontName', 'Times New Roman','Interpreter','LaTex');
% legen = legend('St. GD, $\rho = 0.95, \mu_0 = 1/m$','In. GD, $\rho = 0.9, \mu_0 = 1/m$','St. GD, $\rho = 0.9, \mu_0 = 30/m$','In. GD, $\rho = 0.75, \mu_0 = 30/m$');
legen = legend('GD, $\rho = 0.93, \mu_0 = 1/m$','IGD, $\rho = 0.75, \mu_0 = 30/m$','SGD, $\rho = 0.9, \mu_0 = 30/m$');
set(legen,'Interpreter','LaTex');
% export_fig 'RMS_IGD_vs_SGD.pdf' -nocrop

