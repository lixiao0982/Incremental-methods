function [y, Acell, X, Aop] = generate_RMSdata( m,n,r,p_fail );

rand('seed',2018);randn('seed',2018);


Uo=randn(n,r);
X=Uo*Uo';
%sensing
y=zeros(m,1); Acell=cell(m,1);
for it=1:m
    Acell{it}=randn(n,n);
    y(it)=trace(X'*Acell{it});
end
%add outliers
s = zeros(m,1);
indx = randperm(m);
s(indx(1:floor(p_fail*m))) = 10*randn(floor(p_fail*m),1);
%observation
y = y + s;

if nargout >= 4
    Aop=zeros(m,n^2);
    for it=1:m
        AA = Acell{it};
        Aop(it,:)=AA(:)';
    end
end


end

