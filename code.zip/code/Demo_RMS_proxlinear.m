clear; 
close all;
rand('seed',2018);randn('seed',2018);

%parameter setting
n=50;  
r = 5;
m = 5*n*r;
p_fail = 0.3;
maxiter = 500;


%-------generate data-------
[y, Acell, X] = generate_RMSdata( m,n,r,p_fail );



%random initialization 
U_0 = randn(n,r);








%----incremental prox linear---- 
mu_0 = 30/m; rho = 0.75;
U = U_0;
U_pre = U;
for Iter = 1:maxiter
    %stepsize 
    mu = mu_0*rho^Iter;
    %calculation
    dist_ed1(Iter) = norm(U*U' - X,'fro');
    %inner incremental loop
    for iter = 1:m
        %precompute
        A = mu * (Acell{iter} + Acell{iter}')* U_pre; 
        b = - mu* trace(U_pre'*Acell{iter}*U_pre) - mu* y(iter);
        scaler = ( trace(A'*U_pre) + b) / norm(A,'fro')^2;
        %subproblem update
        if scaler > 1
            U = U_pre - A;
        elseif scaler < -1
            U = U_pre + A;
        elseif scaler >= -1 && scaler <= 1
            U = U_pre - scaler*A;
        end
        %base point update 
        U_pre = U; 
    end
    
end







%----stochastic prox linear---- 
mu_0 = 30/m; rho = 0.9;
U = U_0;
U_pre = U;
for Iter = 1:maxiter
    %stepsize 
    mu = mu_0*rho^Iter;
    %calculation
    dist_ed2(Iter) = norm(U*U' - X,'fro');
    %inner incremental loop
    for iter = 1:m
        index = randperm(m,1); %draw the index uniform at random from 1 to m
        %precompute
        A = mu * (Acell{index} + Acell{index}')* U_pre; 
        b = - mu* trace(U_pre'*Acell{index}*U_pre) - mu* y(index);
        scaler = ( trace(A'*U_pre) + b) / norm(A,'fro')^2;
        %subproblem update
        if scaler > 1
            U = U_pre - A;
        elseif scaler < -1
            U = U_pre + A;
        elseif scaler >= -1 && scaler <= 1
            U = U_pre - scaler*A;
        end
        %base point update 
        U_pre = U; 
    end
    
end





figure;
semilogy(dist_ed1,'r--','LineWidth',2);
hold on
semilogy(dist_ed2,'k-.','LineWidth',2); 
% xlim([0 500])
ylim([1e-15 100])
% set(gcf,'Position',[100 300 650 300],'color','w');
set(gca, 'LineWidth' , 1.8,'FontSize',20);
set(gcf, 'Color', 'w');
xlabel('Iteration','FontSize',20);
ylabel('dist$({\bf U}_k, {\cal U})$','FontSize',25,'FontName', 'Times New Roman','Interpreter','LaTex');
% legen = legend('St. Prox-Linear, $\rho = 0.95, \mu_0 = 1/m$','In. Prox-Linear, $\rho = 0.9, \mu_0 = 1/m$',...
%     'St. Prox-Linear, $\rho = 0.9, \mu_0 = 30/m$','In. Prox-Linear, $\rho = 0.75, \mu_0 = 30/m$');
legen = legend('IPL, $\rho = 0.75, \mu_0 = 30/m$','SPL, $\rho = 0.95, \mu_0 = 30/m$');
set(legen,'Interpreter','LaTex');




