%  Iterpretation:
%For full prox-linear algorithm, we need to use a large constant mu = mu_0, like mu_0 = 1;
%For incremetal version, we need to geometrically diminish stepsize and start with a small mu_0, like in incremental subgradient method

clear; 
close all;
rand('seed',2018);randn('seed',2018);
addpath(genpath('minFunc'))

%parameter setting
n = 100;  
m = 10*n;
p_fail = 0.3;
maxiter = 500;


%-----generate data-----  
[ b, A, xo ] = generate_RPRdata( m,n,p_fail );

%random initialization
x_0 = randn(n,1);







%----incremental prox linear---- 
mu_0 = 1/m; rho = 0.7;
x = x_0;
x_pre = x;
for Iter = 1:maxiter
    %stepsize 
    mu = mu_0*rho^Iter;
     %calculation
    dist_ed1(Iter) = min(norm(x-xo,'fro'),norm(x+xo,'fro'));
    %inner incremental loop
    for iter = 1:m
        %precompute
        aix = A(iter,:)*x_pre;
        aa = 2*mu*aix* A(iter,:)';
        bb = -mu*( aix^2 + b(iter));
        scaler = ( aa'*x_pre + bb ) / norm(aa,'fro')^2;;
        %subproblem update
        if scaler > 1
            x = x_pre - aa;
        elseif scaler < -1
            x = x_pre + aa;
        elseif scaler >= -1 && scaler <= 1
            x = x_pre - scaler*aa;
        end
        %base point update 
        x_pre = x; 
    end

end




%----stochastic prox linear---- 
mu_0 = 150/m; rho = 0.8;
x = x_0;
x_pre = x;
for Iter = 1:maxiter
    %stepsize 
    mu = mu_0*rho^Iter;
    %calculation
    dist_ed2(Iter) = min(norm(x-xo,'fro'),norm(x+xo,'fro'));
    %inner incremental loop
    for iter = 1:m
        idx = randperm(m,1);
        %precompute
        aix = A(idx,:)*x_pre;
        aa = 2*mu*aix* A(idx,:)';
        bb = -mu*( aix^2 + b(idx));
        scaler = ( aa'*x_pre + bb ) / norm(aa,'fro')^2;;
        %subproblem update
        if scaler > 1
            x = x_pre - aa;
        elseif scaler < -1
            x = x_pre + aa;
        elseif scaler >= -1 && scaler <= 1
            x = x_pre - scaler*aa;
        end
        %update the proximal base point
        x_pre = x; 
    end

end






figure;
semilogy(dist_ed1,'r--','LineWidth',2); hold on
semilogy(dist_ed2,'b-.','LineWidth',2); 
% xlim([0 500])
ylim([1e-15 100])
% set(gcf,'Position',[100 300 650 300],'color','w');
set(gca, 'LineWidth' , 1.8,'FontSize',20);
set(gcf, 'Color', 'w');
xlabel('Iteration','FontSize',20);
ylabel('dist$({\bf x}_k, {\cal D})$','FontSize',25,'FontName', 'Times New Roman','Interpreter','LaTex');
legen = legend('IPL, $\rho = 0.7, \mu_0 = 1/m$','SPL, $\rho = 0.8, \mu_0 = 150/m$');
set(legen,'Interpreter','LaTex');


